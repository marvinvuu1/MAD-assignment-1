package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void handleNum(View v){
        EditText ma = findViewById(R.id.m_a);
        EditText ir = findViewById(R.id.i_r);
        EditText mt = findViewById(R.id.m_t);
        TextView result = findViewById(R.id.result);

        double mort = Double.parseDouble(ma.getText().toString());
        double rate = Double.parseDouble(ir.getText().toString());
        rate = rate/100;
        double ten = Double.parseDouble(mt.getText().toString());

        double pow = Math.pow(1+rate, ten);
        double calc = mort * (( rate * pow) / (pow - 1));
        result.setText(String.valueOf(calc));
    }
}